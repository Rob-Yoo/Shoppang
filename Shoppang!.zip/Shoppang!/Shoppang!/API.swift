//
//  API.swift
//  Shoppang!
//
//  Created by Jinyoung Yoo on 6/16/24.
//

import Foundation
import Alamofire

struct API {
    static private let clientID = HTTPHeader(name: "X-Naver-Client-Id", value: "M9lwpPFIVRt3KXVjp2Cq")
    static private let clientSecret = HTTPHeader(name: "X-Naver-Client-Secret", value: "B8sTE4reQ9")

    static let headers: HTTPHeaders = [clientID, clientSecret]
    static func searchProductURL(query: String, sort: String, page start: Int) -> String {
        return "https://openapi.naver.com/v1/search/shop.json?query=\(query)&sort=\(sort)&display=30&start=\(start)"
    }
}
