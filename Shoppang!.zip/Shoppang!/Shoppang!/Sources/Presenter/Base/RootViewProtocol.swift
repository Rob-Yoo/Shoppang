//
//  RootViewProtocol.swift
//  Shoppang!
//
//  Created by Jinyoung Yoo on 6/14/24.
//

import Foundation

protocol RootViewProtocol {
    var navigationTitle: String { get }
}
