//
//  AppleProductCollectionViewCell.swift
//  Shoppang!
//
//  Created by Jinyoung Yoo on 6/25/24.
//

import UIKit
import SnapKit
import Kingfisher
import Then

final class AppleProductCollectionViewCell: UICollectionViewCell {
    
    let productImageView = ProductImageView(hasCartButton: false).then {
        $0.contentMode = .scaleAspectFit
        $0.imageView.layer.borderWidth = 0
    }
    
    private let mallNameLabel = UILabel().then {
        $0.textColor = .placeholder
        $0.font = .regular13
        $0.backgroundColor = .red
    }
    
    private let productNameLabel = UILabel().then {
        $0.textColor = .black
        $0.numberOfLines = 2
        $0.font = .medium13
        $0.backgroundColor = .green
    }
    
    private let priceLabel = UILabel().then {
        $0.textColor = .black
        $0.font  = .bold13
        $0.backgroundColor = .blue
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.contentView.backgroundColor = .white
        self.configureHierarchy()
        self.configureLayout()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func configureCellData(data: Product) {
        let url = URL(string: data.image)
        let formattedPrice = Int(data.lprice)!.formatted()

        self.productImageView.imageView.kf.setImage(with: url)
        self.mallNameLabel.text = data.mallName
        self.productNameLabel.text = data.title.htmlElementDeleted
        self.priceLabel.text = formattedPrice + "원"
    }
}

//MARK: - Configure Subviews
extension AppleProductCollectionViewCell {
    private func configureHierarchy() {
        self.contentView.addSubview(productImageView)
        self.contentView.addSubview(mallNameLabel)
        self.contentView.addSubview(productNameLabel)
        self.contentView.addSubview(priceLabel)
    }
    
    private func configureLayout() {
        productImageView.snp.makeConstraints {
            $0.top.equalToSuperview().offset(10)
            $0.horizontalEdges.equalToSuperview().inset(20)
            $0.height.equalTo(productImageView.snp.width)
        }
        
        mallNameLabel.snp.makeConstraints {
            $0.top.equalTo(productImageView.snp.bottom).offset(5)
            $0.leading.equalToSuperview().offset(5)
        }
        
        priceLabel.snp.makeConstraints {
            $0.leading.equalToSuperview().offset(5)
            $0.bottom.equalToSuperview().inset(5)
        }
        
        productNameLabel.snp.makeConstraints {
            $0.top.greaterThanOrEqualTo(mallNameLabel.snp.bottom).offset(5)
            $0.horizontalEdges.equalToSuperview().inset(5)
            $0.bottom.greaterThanOrEqualTo(priceLabel.snp.top).offset(-5)
//            $0.centerY.equalTo(mallNameLabel.snp)
        }
        
    }
}
